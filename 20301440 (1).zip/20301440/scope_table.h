#include "symbol_info.h"

class scope_table
{
private:
    int bucket_count;
    int unique_id;
    scope_table *parent_scope = NULL;
    vector<list<symbol_info *>> table;


    int hash_function(std::string name) {
        int hash_value = 0;
        for (char ch : name) {
            hash_value = (hash_value * 31 + ch) % bucket_count;
        }
        return hash_value;
    }

public:
    scope_table();
    scope_table(int bucket_count, int unique_id, scope_table *parent_scope);
    scope_table *get_parent_scope();
    int get_unique_id();
    symbol_info *lookup_in_scope(symbol_info* symbol);
    bool insert_in_scope(symbol_info* symbol);
    bool delete_from_scope(symbol_info* symbol);
    void print_scope_table(ofstream& outlog);
    void clear_scope_table();
    ~scope_table();

    // you can add more methods if you need
};

// Complete the methods of scope_table class
symbol_info* scope_table::lookup_in_scope(symbol_info* symbol) {
    int hash_val = hash_function(symbol->get_name());
    for (symbol_info* sym : table[hash_val]) {
        if (sym->get_name() == symbol->get_name()) {
            return sym;
        }
    }
    return nullptr;
}

bool scope_table::insert_in_scope(symbol_info* symbol) {
    int hash_val = hash_function(symbol->get_name());
    for (symbol_info* sym : table[hash_val]) {
        if (sym->get_name() == symbol->get_name()) {
            return false; // Symbol already exists
        }
    }
    table[hash_val].push_back(symbol);
    return true; // Insertion successful
}

bool scope_table::delete_from_scope(symbol_info* symbol) {
    int hash_val = hash_function(symbol->get_name());
    for (auto it = table[hash_val].begin(); it != table[hash_val].end(); ++it) {
        if ((*it)->get_name() == symbol->get_name()) {
            table[hash_val].erase(it);
            return true; // Deletion successful
        }
    }
    return false; // Symbol not found
}

void scope_table::print_scope_table(ofstream& outlog) {
    outlog << "ScopeTable # " << unique_id << endl;
    for (int i = 0; i < bucket_count; ++i) {
        outlog << i << " --> " << endl;
        for (symbol_info* sym : table[i]) {
            outlog << "< " << sym->get_name() << " : " << sym->get_type() << " >" << endl;
        }
    }
}


void scope_table::print_scope_table(std::ofstream& outlog) {
    outlog << "ScopeTable # " << unique_id << std::endl;

    // Iterate through the buckets
    for (int i = 0; i < bucket_count; ++i) {
        // Print the bucket number
        outlog << i << " -->" << std::endl;

        // Iterate through the symbols in the bucket
        for (symbol_info* sym : table[i]) {
            // Print symbol information
            outlog << "< " << sym->getname() << " : " << sym->get_type() << " >" << std::endl;
        }
    }
}

void scope_table::clear_scope_table() {
    for (int i = 0; i < bucket_count; ++i) {
        table[i].clear();
    }
}

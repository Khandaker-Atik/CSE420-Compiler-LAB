#include<bits/stdc++.h>
using namespace std;

class symbol_info
{
private:
    string name;
    string type;
    string symbol_type; // variable, array, or function
    string return_type; // return type of a function
    vector<pair<string, string>> parameters; // parameters of a function
    int array_size; // size of the array if the symbol is an array
    

public:
    symbol_info(string name, string type, string symbol_type = "variable")
    {
        this->name = name;
        this->type = type;
        this->symbol_type = symbol_type;
        this->return_type = ""; // default return type
        this->array_size = -1; // default array size
    }

    string get_name()
    {
        return name;
    }

    string get_type()
    {
        return type;
    }

    string get_symbol_type() 
    {
        return symbol_type;
    }

    string get_return_type() 
    {
        return return_type;
    }

    vector<pair<string, string>> get_parameters()
    {
        return parameters;
    }

    int get_array_size() 
    {
        return array_size;
    }

    void set_name(string name)
    {
        this->name = name;
    }

    void set_type(string type)
    {
        this->type = type;
    }

    void set_symbol_type(string symbol_type)
    {
        this->symbol_type = symbol_type;
    }

    void set_return_type(string return_type)
    {
        this->return_type = return_type;
    }

    void set_parameters(const vector<pair<string, string>>& parameters)
    {
        this->parameters = parameters;
    }

    void add_parameter(string type, string name)
    {
        parameters.push_back({type, name});
    }

    void set_array_size(int array_size)
    {
        this->array_size = array_size;
    }


    ~symbol_info()
    {
        // Write necessary code to deallocate memory, if necessary
    }
};